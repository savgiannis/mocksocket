$(function () {


  $('#TA-approve').click(() => {
    axios.get('http://localhost:3000/taResponse', {
      params: {
        action: 'approve'
      }
    });
  })

  $('#TA-decline').click(() => {
    axios.get('http://localhost:3000/taResponse', {
      params: {
        action: 'decline'
      }
    });
  });

  var settings = {
    "async": true,
    "crossDomain": true,
    "url": "https://sandbox-api.everypay.gr/tokens",
    "method": "POST",
    "headers": {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic cGtfQnhCQ3VSQ1NITGQxRkhUY0F1c0F1NUNtOG1Dc1NOaE06"
    },
    "data": {
      "card_number": "4556390755719395",
      "expiration_year": "2020",
      "expiration_month": "11",
      "holder_name": "Giannis Savvidis",
      "cvv": "123"
    }
  }

  $.ajax(settings).done(function (response) {
    console.log(response);
  });

});